                  <div class="course__sidebar profile_sidebar pl-25 mt-160 shadow-lg">
                        <div class="course__sidebar-widget profile-card grey-bg">
                           <div class="course__sidebar-info profile-sidebar">
                           <a href="<?php echo base_url()?>index.php/Home/profile"><img src="<?php echo base_url()?>assets/assets/img/testimonial/testi-1.jpg" class="rounded-circle mx-auto d-block"></a>
                              <h3 class="course__sidebar-title">Profile</h3>
                              <ul>
                                 <!-- <li> -->
                                 <li><a href="<?php echo base_url()?>index.php/Home/profile"><i class="fal fa-user"></i>&nbsp My Profile</a></li>
                                 <hr></hr>
                                 <li><a href="<?php echo base_url()?>index.php/Home/mycourse"><i class="fal fa-book"></i>&nbsp My Course</a></li>
                                 <hr></hr>
                                 <li><a href="<?php echo base_url()?>index.php/Home/wishlist"><i class="fal fa-heart"></i>&nbsp Wishlist</a></li>
                                 <hr></hr>
                                 <li><a href="<?php echo base_url()?>index.php/Home/notification1"><i class="fal fa-bell"></i>&nbsp Notification</a></li>
                                 <hr></hr>
                                 <li><a href="<?php echo base_url()?>index.php/Home/change_password"><i class="fal fa-key"></i>&nbsp Change Password</a></li>
                                 <hr></hr>
                                 <li><a href="#"><i class="fal fa-sign-out"></i>&nbsp Logout</a></li>
                              </ul>
                           </div>
                        </div>
                   </div>