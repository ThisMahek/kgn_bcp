

                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> ©.copy
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Design & Develop by <a href="#!" class="text-decoration-underline"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        
     

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- JAVASCRIPT -->
        <script src="<?php echo base_url()?>assets_admin/libs/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url()?>assets_admin/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo base_url()?>assets_admin/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?php echo base_url()?>assets_admin/libs/simplebar/simplebar.min.js"></script>
        <script src="<?php echo base_url()?>assets_admin/libs/node-waves/waves.min.js"></script>
        <script src="<?php echo base_url()?>assets_admin/libs/feather-icons/feather.min.js"></script>
        <!-- pace js -->
        <script src="<?php echo base_url()?>assets_admin/libs/pace-js/pace.min.js"></script>

        <!-- apexcharts -->
        <script src="<?php echo base_url()?>assets_admin/libs/apexcharts/apexcharts.min.js"></script>

        <!-- Plugins js-->
        <script src="<?php echo base_url()?>assets_admin/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="<?php echo base_url()?>assets_admin/libs/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js"></script>
        <!-- dashboard init -->
        <script src="<?php echo base_url()?>assets_admin/js/pages/dashboard.init.js"></script>

        <script src="<?php echo base_url()?>assets_admin/js/app.js"></script>

        
        <!-- Responsive examples -->
        <script src="<?php echo base_url()?>assets_admin/libs/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()?>assets_admin/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

         <!-- Datatable init js -->
         <script src="<?php echo base_url()?>assets_admin/js/pages/datatables.init.js"></script>    

    </body>


</html>