<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	public function __construct()
        {
           parent:: __construct();
           
          $this->load->model("project_model","pro");
		  $this->load->model("basic_model","bm");	

		   $std_id=$this->session->std_id;
           $db_name=$this->session->db_name;
            if($std_id==""){
                
                redirect('logout');
            }	
	
        }



	public function index()
	{
	     $std_id=$this->session->std_id;
         $db_name=$this->session->db_name;
	    $cdn="SELECT * FROM `education_center_master` WHERE `master_id`='$std_id'";
	    $data['stu_info']=$this->bm->quert($db_name,$cdn);
	    
	    
	    $cdn_courses="SELECT * FROM `education_center_mcourses`";
	    $data['all_course']=$this->bm->quert($db_name,$cdn_courses);
	    
	    
	    
		
		$this->load->view('student/lib/header',$data);
		//$this->load->view('student/lib/sidebar');
		$this->load->view('student/dashboard/profile');
		$this->load->view('student/lib/footer');
		
	}
	
		public function change_password()
	{
	     $std_id=$this->session->std_id;
         $db_name=$this->session->db_name;
	    $cdn="SELECT * FROM `education_center_master` WHERE `master_id`='$std_id'";
	    $data['stu_info']=$this->bm->quert($db_name,$cdn);
	    
	    
	    $cdn_courses="SELECT * FROM `education_center_mcourses`";
	    $data['all_course']=$this->bm->quert($db_name,$cdn_courses);
	    
	    
	    
		
		$this->load->view('student/lib/header',$data);
		//$this->load->view('student/lib/sidebar');
		$this->load->view('student/dashboard/cp');
		$this->load->view('student/lib/footer');
		
	}
	public function ucp(){
	    
	    $std_id=$this->session->std_id;
        $db_name=$this->session->db_name;
        
        $password=$_POST['new_pass'];
        $update_data=["master_password"=>$password,];
        $cdn=["master_id"=>$std_id,];
        $tbl='master';
          $upp=$this->bm->update($db_name,$tbl,$cdn,$update_data);
                 if($upp){ 
                     redirect('student/profile/change_password');
                 }
        
	    
	}
	
	public function ch_opa(){
	    
	    $std_id=$this->session->std_id;
        $db_name=$this->session->db_name;
        $opa=$_POST['opa'];
	    $cdn="SELECT `master_password` FROM `education_center_master` WHERE `master_id`='$std_id' AND `master_password`='$opa'";
	    $stu_info=$this->bm->quert($db_name,$cdn);
	    $countsio=count($stu_info);
	    if($countsio==0){
	        echo'0';
	    }else{
	        echo'1';
	    }
	    
	}
	
	
	public function showcity(){
	    $db_name=$this->session->db_name;
	    $val=$_POST['val'];
	     $cdbn="SELECT `city_name` AS city FROM `education_center_city` WHERE `city_state`='$val'";
 $st_arr=$this->bm->quert($db_name,$cdbn);
 $html="";
 $html.="<select class='form-control' name='city' id='exampleFormControlSelect2' required>
        <option value=''>Select City</option></option>";
    foreach($st_arr as $st_arr){ 
        $city=$st_arr['city'];
    $html.="<option value='$city'>$city</option>";
    }  
        
    $html.="</select>";
    
    echo $html;
 
 
	}
	public function add_profile()
	{
	     $std_id=$this->session->std_id;
         $db_name=$this->session->db_name;
        //echo"<pre>";
        // print_r($_POST);
        // exit;
        $name=$_POST['name'];
        $fname=$_POST['fname'];
        $mname=$_POST['mname'];
        $class=$_POST['class'];
        
        $address=$_POST['Address'];
        
        $roll_no=$_POST['roll_no'];
        $aadhar_no=$_POST['aadhar_no'];
        $state=$_POST['state'];
        $city=$_POST['city'];
        $pin_no=$_POST['pin_no'];
        $mobile=$_POST['mobile'];
        $file_data = $this->pro->upload('pro_img','./upload/stu_profile/','1000');
           

        //echo"<pre>";
        //print_r($file_data);
      //exit;


        if(isset($file_data['success'][0]['file_name']) && $file_data['success'][0]['file_name'] !=''){
               
                $file_name=$file_data['success'][0]['file_name'];
                
           
                
                $update_data=[
                    "master_name"=>$name,
                    "master_fname"=>$fname,
                    "master_mname"=>$mname,
                    "master_mobile"=>$mobile,
                    "master_class"=>$class,
                    "master_image"=>$file_name,
                    "master_address"=>$address,
                    "master_roll_no"=>$roll_no,
                    "master_aadhar_no"=>$aadhar_no,
                    "master_state"=>$state,
                    "master_city"=>$city,
                    "master_pin_no"=>$pin_no,
                    ];
                $tbl='master'; 
                $cdn=["master_id"=>$std_id,];
                $upp=$this->bm->update($db_name,$tbl,$cdn,$update_data);
                 if($upp){ 
                     redirect('student/dashboard');
                 }
               
           }else{
               
               echo$file_data['error'][0];
               redirect('student/dashboard');
           }
        
	
	}

}
