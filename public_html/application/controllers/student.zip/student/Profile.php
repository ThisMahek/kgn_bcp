<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	public function __construct()
        {
           parent:: __construct();
           
          $this->load->model("project_model","pro");
		  $this->load->model("basic_model","bm");
         $this->load->model('htmltopdf_model');
          $this->load->library('pdf');
                   

         	   $std_id=$this->session->std_id;
           $db_name=$this->session->db_name;
          $this->load->library('pdf');
	
            if($std_id==""){
                
                //redirect('logout');
            }	
	
        }



	public function index()
	{
	     $std_id=$this->session->std_id;

         
         $db_name=$this->session->db_name;
	    $cdn="SELECT * FROM `education_center_master` WHERE `master_id`='$std_id'";
	    $data['stu_info']=$this->bm->quert($db_name,$cdn);
	    
	    
	    $cdn_courses="SELECT * FROM `education_center_mcourses`";
	    $data['all_course']=$this->bm->quert($db_name,$cdn_courses);
	    
	    
	     $data['customer_data'] = $this->bm->quert($db_name,$cdn);
      //$this->load->view('student/dashboard/profile');
        
		//$data['customer_data'] = $this->Htmltopdf_model->fetch_single_details($db_name,$std_id);

		$this->load->view('student/lib/header',$data);
		//$this->load->view('student/lib/sidebar');
		$this->load->view('student/dashboard/profile', $data);
		$this->load->view('student/lib/footer');
		
	}
	
		public function change_password()
	{
	     $std_id=$this->session->std_id;
         $db_name=$this->session->db_name;
	    $cdn="SELECT * FROM `education_center_master` WHERE `master_id`='$std_id'";
	    $data['stu_info']=$this->bm->quert($db_name,$cdn);
	    
	    
	    $cdn_courses="SELECT * FROM `education_center_mcourses`";
	    $data['all_course']=$this->bm->quert($db_name,$cdn_courses);
	    
	    
	    
		
		$this->load->view('student/lib/header',$data);
		//$this->load->view('student/lib/sidebar');
		$this->load->view('student/dashboard/cp');
		$this->load->view('student/lib/footer');
		
	}
	public function ucp(){
	    
	    $std_id=$this->session->std_id;
        $db_name=$this->session->db_name;
        
        $password=$_POST['new_pass'];
        $update_data=["master_password"=>$password,];
        $cdn=["master_id"=>$std_id,];
        $tbl='master';
          $upp=$this->bm->update($db_name,$tbl,$cdn,$update_data);
                 if($upp){ 
				 $this->session->set_flashdata('cp_succ','Password Changed Successfully.');
                     redirect('student/profile/change_password');
                 }
        
	    
	}
	
	public function ch_opa(){
	    
	    $std_id=$this->session->std_id;
        $db_name=$this->session->db_name;
        $opa=$_POST['opa'];
	    $cdn="SELECT `master_password` FROM `education_center_master` WHERE `master_id`='$std_id' AND `master_password`='$opa'";
	    $stu_info=$this->bm->quert($db_name,$cdn);
	    $countsio=count($stu_info);
	    if($countsio==0){
	        echo'0';
	    }else{
	        echo'1';
	    }
	    
	}
	
	
	public function showcity(){
	    $db_name=$this->session->db_name;
	    $val=$_POST['val'];
	     $cdbn="SELECT `city_name` AS city FROM `education_center_city` WHERE `city_state`='$val'";
 $st_arr=$this->bm->quert($db_name,$cdbn);
 $html="";
 $html.="<select class='form-control' name='city' id='exampleFormControlSelect2' required>
        <option value=''>Select City</option></option>";
    foreach($st_arr as $st_arr){ 
        $city=$st_arr['city'];
    $html.="<option value='$city'>$city</option>";
    }  
        
    $html.="</select>";
    
    echo $html;
 
 
	}
	public function add_profile()
	{
	     $std_id=$this->session->std_id;
         $db_name=$this->session->db_name;
   
        
        
        $name=$_POST['name'];
        $fname=$_POST['fname'];
        $mname=$_POST['mname'];
        $class=$_POST['class'];
        
        $address=$_POST['Address'];
        
        $roll_no=$_POST['roll_no'];
        $aadhar_no=$_POST['aadhar_no'];
        $state=$_POST['state'];
        $city=$_POST['city'];
        $pin_no=$_POST['pin_no'];
        $mobile=$_POST['mobile'];
        $file_data = $this->pro->upload('pro_img','./upload/stu_profile/','1000');
           

        //echo"<pre>";
        //print_r($file_data);
      //exit;
 if(isset($file_data['success'][0]['file_name']) && $file_data['success'][0]['file_name'] !=''){
               
                $file_name=$file_data['success'][0]['file_name'];
                
           
                
                $update_data=[
                    "master_name"=>$name,
                    "master_fname"=>$fname,
                    "master_mname"=>$mname,
                    "master_mobile"=>$mobile,
                    "master_class"=>$class,
                    "master_image"=>$file_name,
                    "master_address"=>$address,
                    "master_roll_no"=>$roll_no,
                    "master_aadhar_no"=>$aadhar_no,
                    "master_state"=>$state,
                    "master_city"=>$city,
                    "master_pin_no"=>$pin_no,
                    ];
                $tbl='master'; 
                $cdn=["master_id"=>$std_id,];
                $upp=$this->bm->update($db_name,$tbl,$cdn,$update_data);
                 if($upp){ 
                   
                     redirect('student/dashboard');
                 }
               
           }else{
               
               echo$file_data['error'][0];
               redirect('student/dashboard');
           }
        
	
	}

    public function delete()
    {
         $std_id=$this->session->std_id;
         $db_name=$this->session->db_name;
   
        $img_delete = " DELETE FROM education_center_master WHERE master_image = '$std_id'";

        $img_del=$this->bm->delete($db_name,$img_delete);
        redirect('student/profile');


 /*     if($img_delete)
     {
        $this->set_flashdata('img_dt','Image delete successfully' );
        redirect('student/profile');

     } else
     {
        $this->set_flashdata('img_warning','Error');
         redirect('student/profile');

     }
   */

    }


public function update_profile()
    {
         $std_id=$this->session->std_id;
         $db_name=$this->session->db_name;
//$file_data = $_POST['pro_img'];
           
 /*$file_data = $this->pro->upload('pro_img', '');
//echo "<pre>";
//print_r($file_data);
//exit;
if($file_data['success'] == '')

{
  $file_dat = '<img src="/upload/stu_profile/dummy-350x350.png" width="250">';

echo $file_dat;


}else
{
    echo "failed";
}
*/

        $name=$_POST['name'];

        $fname=$_POST['fname'];
        $mname=$_POST['mname'];
        $student_type=$_POST['Type'];
        $center=$_POST['fcname'];


        $class=$_POST['class'];
        
        $address=$_POST['Address'];
        
        $roll_no=$_POST['roll_no'];
        $aadhar_no=$_POST['aadhar_no'];
        $state=$_POST['state'];
        $city=$_POST['city'];
        $pin_no=$_POST['pin_no'];
        $mobile=$_POST['mobile'];
        $image= "dummy-350x350.png";


  

        $file_data = $this->pro->upload('pro_img','./upload/stu_profile/','1000');
     //   $file_data=$_POST['pro_img'];
    

       // echo"<pre>";
        //print_r($file_data);
      //exit;
 if(isset($file_data['success'][0]['file_name']) && $file_data['success'][0]['file_name'] !=''){
               
               $file_name=$file_data['success'][0]['file_name'];
                
           
                
                $update_data=[
                    "master_name"=>$name,
                    "student_type"=>$student_type,
                    "facilitation_center_name"=>$center,
                    "master_fname"=>$fname,
                    "master_mname"=>$mname,
                    "master_mobile"=>$mobile,
                    "master_class"=>$class,
                    "master_image"=>$file_name,
                    "master_address"=>$address,
                    "master_roll_no"=>$roll_no,
                    "master_aadhar_no"=>$aadhar_no,
                    "master_state"=>$state,
                    "master_city"=>$city,
                    "master_pin_no"=>$pin_no,
                    ];


                 

                   
                $tbl='master'; 
                $cdn=["master_id"=>$std_id,];
                $upp=$this->bm->update($db_name,$tbl,$cdn,$update_data);
                 if($upp){ 
                   
                   $this->session->set_flashdata("add_succ"," profile Update successfully.");
                
                     redirect('student/dashboard');
                 }
               
           }else{

                      if($file_data['success'] == '')

{
        




           	$update_data=[
                    "master_name"=>$name,
                    "student_type"=>$student_type,
                    "facilitation_center_name"=>$center,
                    "master_fname"=>$fname,
                    "master_mname"=>$mname,
                    "master_mobile"=>$mobile,
                    "master_class"=>$class,
                    "master_image"=>$image,
                    "master_address"=>$address,
                    "master_roll_no"=>$roll_no,
                    "master_aadhar_no"=>$aadhar_no,
                    "master_state"=>$state,
                    "master_city"=>$city,
                    "master_pin_no"=>$pin_no,
                    ];


                 

                   
                $tbl='master'; 
                $cdn=["master_id"=>$std_id,];
                $upp=$this->bm->update($db_name,$tbl,$cdn,$update_data);
                 if($upp){ 
                   
                   $this->session->set_flashdata("add_succ"," profile Update successfully.");
                
                     redirect('student/dashboard');
                 }
           }else{





           	$update_data=[
                    "master_name"=>$name,
                    "student_type"=>$student_type,
                    "facilitation_center_name"=>$center,
                    "master_fname"=>$fname,
                    "master_mname"=>$mname,
                    "master_mobile"=>$mobile,
                    "master_class"=>$class,
                    
                    "master_address"=>$address,
                    "master_roll_no"=>$roll_no,
                    "master_aadhar_no"=>$aadhar_no,
                    "master_state"=>$state,
                    "master_city"=>$city,
                    "master_pin_no"=>$pin_no,
                    ];


                 

                   
                $tbl='master'; 
                $cdn=["master_id"=>$std_id,];
                $upp=$this->bm->update($db_name,$tbl,$cdn,$update_data);
                 if($upp){ 
                   
                   $this->session->set_flashdata("add_succ"," profile Update successfully.");
                
                     redirect('student/dashboard');




           }

}


       }
        }
    
    


	public function pdfdetails(){
  if($this->uri->segment(4))
        {
            $customer_id = $this->uri->segment(4);
            $html_content = " <b style='color: red;   font-size: 50px; font-family: Serif; text-shadow: 5px 5px 10px black;'>K G N </b><br> <b style='font-size: 15px; float:left';>C O M P U T E R &nbsp; A C A D E M Y   
    </b>"." " ."<br><b style='font-size:10px'> Corporate Office:- 438/1A, 1st Floor, Behind Saint Jude’s School, Prem Nagar, Nagra Jhansi – 284003<br></b>
       <b style='font-size: 10px; float:left';>City Office:- Above PNB ATM, Kachari Chauraha Corner, Jhansi UP- 284001<br>
       </b>
       <br><b style='font-size: 10px; float:left';>Tel: +91-510-2310287, Cell:- +91-8004273287, +91-8707786340</b><br>
<b style='font-size: 10px; float:left';>Web Site: https://www.kgncomputeracademy.org, Email:- kgn.computer.academy@gmail.com</b>

                <br>Skill Training || 3rd Party Assessment || Entrepreneurship Development || Vocational Course<br>
                <br>";
            $html_content .= $this->htmltopdf_model->fetch_single_details($customer_id);
        
            $this->pdf->loadHtml($html_content);
            $this->pdf->render();
            $this->pdf->stream("".$customer_id.".pdf", array("Attachment"=>0));
        }
}

}
